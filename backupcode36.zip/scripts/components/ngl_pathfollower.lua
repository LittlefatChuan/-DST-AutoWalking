require("utils/step_util")
require("utils/bit_operate_util")

local SERVER_LEFTCLICK_DIST_SQ = 4096

-- the status of pathsearch
local STATUS_CALCULATING = 0
local STATUS_FOUNDPATH = 1
local STATUS_NOPATH = 2

--should adjust them according to the player's speed, increase them when high speed
local FORCESTOP_OFFSET = 2
local ARRIVESTEP_MOVEMENTPREDICT_ENABLED = .5
local ARRIVESTEP_MOVEMENTPREDICT_DISABLED = 1.5 -- make it larger to handle the lag when lag compensation OFF.

-- move mode
local MOVEMODE_LEFTCLICK = 0	-- via Remote Call locomotor:GoToPoint(), ACTONS.WALKTO actually
local MOVEMODE_DIRECTWALK = 1	-- via Remote Call locomotor:RunInDirection()

-- groundcaps setting for astar pathfinder
local ASTAR_SPEED_FASTER = 1
local ASTAR_SPEED_NORMAL = 0
local ASTAR_SPEED_SLOWER = -1

-- only beyond this distance should we correct direction in DIRECTWALK movemode
local REDIRECT_DIST = 1

-- make the distance between adjacent pathsteps in range of sendLeftClickRPC
-- it's unnecessary in DIRECTWALK Mode, but still should do it to handle the case when toggle to the LEFTCLICK Mode during the path following
local function preprocess_path(path)
	--print(#path.steps)
	local index = 2
	while(index <= #(path.steps)) do
		local pre = StepToVector3(path.steps[index-1])
		local current = StepToVector3(path.steps[index])

		if pre:DistSq(current) > SERVER_LEFTCLICK_DIST_SQ then -- out of range
			local inrange_pos = (current - pre):GetNormalized()* (50)+pre
			table.insert(path.steps, index, Vector3ToStep(inrange_pos))
			--print("after split",StepToVector3(path.steps[index-1]):Dist(StepToVector3(path.steps[index])))
		else
			index = index + 1
		end
	end
	return path
end

-- just for debug to check the dest of each steps
local function checkDist(path)
	print(#path.steps)
	for index = 2,#(path.steps) do
		local pre = StepToVector3(path.steps[index-1])
		local current = StepToVector3(path.steps[index])
		local distsq = pre:DistSq(current)
		print(distsq)
		-- if distsq > SERVER_LEFTCLICK_DIST_SQ then -- out of range
			-- print("outofrange",distsq)
		-- end
	end
end

-- when we get a path ,just make the character following it
local function follow_path(inst)
	local self = inst.components.ngl_pathfollower
	local path = self.path
	if self.dest == nil then return end
	local time = GetTime()
	if self.extra_check_fn ~= nil and time >= self.last_check_time + self.extra_check_interval then
		self.extra_check_fn(inst)
		self.last_check_time = time
	end
	local in_idle = inst:HasTag("idle") -- official tag
	local arrive_currentstep = inst:HasTag("arrive_currentstep") -- my tag

	local player_pos = inst:GetPosition()
	player_pos.y = 0

	local currentstep_pos = StepToVector3(path.steps[path.currentstep]) -- {y,x,z} --> Vector3
	
	local step_distsq = player_pos:DistSq(currentstep_pos)
	
	-- Add tolerance to step points.
	local physdiameter = self.inst:GetPhysicsRadius(0)*2
	step_distsq = step_distsq - physdiameter * physdiameter

	local arrive_step_dist = self:GetArriveStep()
	if step_distsq <= (arrive_step_dist)*(arrive_step_dist) then
		local maxsteps = #self.path.steps
		if self.path.currentstep < maxsteps then
			self.path.currentstep = self.path.currentstep + 1
			self.inst:PushEvent("ngl_startnextstep", {currentstep = self.path.currentstep})
			local step = self.path.steps[self.path.currentstep]
			self:Move(StepToVector3(step))
			--print("switch to nextstep")
		else
			self.inst:PushEvent("ngl_onreachdestination",{ pos = self.dest })
			if self.atdestfn ~= nil then
				self.atdestfn(self.inst)
			end
			--print("arrive the dest")
			
			self:ForceStop()
		end
	elseif in_idle or arrive_currentstep then
		self:Move(currentstep_pos)
		--print("revoke the follow")
	end
	
	
end

-- check for arrival after the path was reset to directwalk
local function check_for_arrival(inst)
	local self = inst.components.ngl_pathfollower
	
	local player_pos = self.inst:GetPosition()
	player_pos.y = 0
	local dest_distsq = player_pos:DistSq(self.dest)

	local arrive_step_dist = self:GetArriveStep()
	if dest_distsq <= (arrive_step_dist)*(arrive_step_dist) then
		self.inst:PushEvent("ngl_onreachdestination",{ pos = self.dest })
		if self.atdestfn ~= nil then
			self.atdestfn(self.inst)
		end
		self:ForceStop()
	end

end

local function IsValidPath(path)
	return path ~= nil and path.steps and #path.steps >= 2 
end

local function is_pathcaps_different_from_locomotors(pathcaps)
	if pathcaps then
		local pathcaps_copy = shallowcopy(pathcaps)
		pathcaps_copy.player = true
		local pathcaps_loco = {player = true, ignorecreep = true}
		for k,v in pairs(pathcaps_copy) do 
			if (pathcaps_copy[k] == true) ~= (pathcaps_loco[k] == true) then
				return true
			end
		end
		
		for k,v in pairs(pathcaps_loco) do 
			if (pathcaps_loco[k] == true) ~= (pathcaps_copy[k] == true) then
				return true
			end
		end
	end
	return false
	
end

-- if the pathfinder is in calcating , just return and waiting for the result in next period
-- if we get a valid path, next is to depart and follow the path
-- if no path or invalid path , try to reach it with direct walking
local function check_search_status(inst)
	local self = inst.components.ngl_pathfollower
	if self ~= nil then
		local pathfinder = self:GetPathfinder()
		local status
		if pathfinder ~= nil then 
			status = pathfinder:GetSearchStatus()
		else
			status = STATUS_NOPATH
		end
		
		if status ~= STATUS_CALCULATING then
			if status == STATUS_FOUNDPATH then
				local foundpath = pathfinder:GetSearchResult()
				if IsValidPath(foundpath) then
					-- always split the path to ensure always in range
					-- cause that we may in DirectWalk mode when trigger and switch to the LEFTCLICK on the way, and fail to send LEFTCLICK RPC with outrange
					--if self:GetMoveMode(true) == MOVEMODE_LEFTCLICK then
					foundpath = preprocess_path(foundpath)
					--checkDist(foundpath)
					--end
					self.path = {}
					self.path.steps = foundpath.steps
					self.path.currentstep = 2
				else
					-- INVALID PATH
					--print("invalid path")
				end
			else
				if status == nil then
					-- LOST PATH SEARCH
					--print("lost search")
				else
					-- NO PATH
					--print("no path")
				end
			end
			
			self.waitsearchresult_task:Cancel()
			self.waitsearchresult_task = nil

			if self.path ~= nil then -- get a path, just follow it 
				self.inst:PushEvent("ngl_startpathfollow", {path = self.path})

				-- call it before SetMoveModeOverrideInternal
				self:RemoteStopDirectWalking()
				-- ensure we will directly walk to handle the difference of path follow result between client and server
				if self.pathcaps then
					self:SetMoveModeOverrideInternal(is_pathcaps_different_from_locomotors(self.pathcaps) and MOVEMODE_DIRECTWALK or nil)
				end
				self:Move(StepToVector3(self.path.steps[self.path.currentstep]))
				self.followpath_task = self.inst:DoPeriodicTask(FRAMES, follow_path, 0)
				
				if self.debugmode then
					self:VisualizePath()
				end
			else -- reset to directwalk
				if self.dest then
					self:SetMoveModeOverrideInternal(MOVEMODE_DIRECTWALK)
					self:Move(self.dest)
					self.check_arrival_for_directwalk_task = self.inst:DoPeriodicTask(FRAMES, check_for_arrival, 0)
					self.inst:PushEvent("ngl_startdirectwalkwithnopath", {dest = self.dest})
				end
			end
		end	
	end
end

-- TODO: need a better way to check if we run off the path
-- you may run off the path cause by the collision and need redirect to correct direction in MOVEMODE_DIRECTWALK
-- local function redirect_fn(inst)
	-- local self = inst.components.ngl_pathfollower
	-- self.extra_check_timer = self.extra_check_timer - FRAMES
	-- if self.extra_check_timer < 0 then
		-- if self.path == nil and self:GetMoveMode(true) ~= MOVEMODE_DIRECTWALK and not self:FollowingPath() then return end
		-- local currentstep_pos = StepToVector3(self.path.steps[self.path.currentstep])
		-- self:Move(currentstep_pos)
		
		-- self.extra_check_timer = self.extra_check_interval
	-- end
-- end

-- the distance between point and line of two points
local function getDistFromPointToLine(point, linePoint1, linePoint2)
	local x0,y0 = point.x, point.z
	local x1,y1 = linePoint1.x, linePoint1.z
	local x2,y2 = linePoint2.x, linePoint2.z
	return math.abs( (x2-x1)*(y0-y1) - (y2-y1)*(x0-x1) ) / math.sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1))
end

-- we should correct the direction if we are far from the path in MOVEMODE_DIRECTWALK
local function redirect_fn2(inst)
	local self = inst.components.ngl_pathfollower
	if self.path == nil or self:GetMoveMode(true) ~= MOVEMODE_DIRECTWALK or not self:FollowingPath() then return end

	local path = self.path
	local player_pos = inst:GetPosition()
	player_pos.y = 0
	local curstep_pos = StepToVector3(path.steps[path.currentstep])
	local prestep_pos = StepToVector3(path.steps[path.currentstep - 1])
	if curstep_pos == prestep_pos then return end -- will result in a denominator of 0 when caculating the distance

	local dist = getDistFromPointToLine(player_pos, prestep_pos, curstep_pos)
	--print("TRAVEL: DIST - ",dist)
	if(dist > REDIRECT_DIST) then
		self:Move(curstep_pos)

	end
end

local PathFollower = Class(function(self, inst)
    self.inst = inst
	
	--self.movemode = MOVEMODE_DIRECTWALK
	self.debugmode = false
	self.debug_signs = nil
	
	self.dest = nil
	self.path = nil
	--self.arrive_step_dist = ARRIVE_STEP
	self.atdestfn = nil
	
	self.extra_check_interval = 5 * FRAMES
	self.last_check_time = 0
	self.extra_check_fn = redirect_fn2
	
	self.waitsearchresult_task = nil
	self.followpath_task = nil
	self.check_arrival_for_directwalk_task = nil

	self.pathfinder = self.inst.components.ngl_astarpathfinder or self.inst.components.ngl_pathfinder

end)

-- GoToPoint works both in the movment prediction
-- doesn't work when we hold something and left action is Drop
function PathFollower:GoToPoint(pos)
	local locomotor = self:GetLocomotor()
	if locomotor then	--lag compensation ON
		local act = BufferedAction(self.inst, nil, ACTIONS.WALKTO)
		locomotor:GoToPoint(pos, act, true)
	else	--lag compensation OFF
		SendRPCToServer(RPC.LeftClick, ACTIONS.WALKTO.code, pos.x, pos.z) -- actually it call locomotor:GoToPoint in dedicated server 
	end
end

-- RunInDirection works both in the movment prediction
-- directwalk mode need a extra task to check if we run off the path
function PathFollower:RunInDirection(dir)
	local locomotor = self:GetLocomotor()
	if locomotor then	--lag compensation ON
		locomotor:RunInDirection(-math.atan2(dir.z, dir.x) / DEGREES)
	else	--lag compensation OFF
		SendRPCToServer(RPC.DirectWalking, dir.x, dir.z) -- actually it call locomotor:RunInDirection in dedicated server 
	end

end

-- the direct walk in server triggered via send DIRECTWALK RPC
-- can only be stop via send StopWalkingRPC and can be redirected via resend DirectWalkingRPC
-- leftclick (ACTIONS.WALKTO) can be cleared internal by both leftclick and directwalk
function PathFollower:RemoteStopDirectWalking()
	-- remote and directwalking
	-- (should preserve the previous movemode to check, so plz call RemoteStopDirectWalking before SetMoveModeOverrideInternal)
	if self:GetLocomotor() == nil and self:GetMoveMode(true) == MOVEMODE_DIRECTWALK then
		SendRPCToServer(RPC.StopWalking)
	end
end

-- select GoToPoint or RunInDirection by self:GetMoveMode()
function PathFollower:Move(pos)

	-- to avoid the case when we arrive the step but keep the previous directwalk state
	self:RemoteStopDirectWalking()

	-- get new movemode
	local movemode = self:GetMoveMode()
	if movemode == MOVEMODE_LEFTCLICK then
		self:GoToPoint(pos)
	elseif movemode == MOVEMODE_DIRECTWALK then
		local player_pos = self.inst:GetPosition()
		player_pos.y = 0
		local normalized_dir = (pos - player_pos):GetNormalized()
		self:RunInDirection(normalized_dir)
	end
end


-- OVERLOAD:
-- 1. Vector3 as input(Vector3)
-- 2. steps as input {{x = x1,y = y1,z = z1},....}
-- 3. path as input {steps = {...}}
function PathFollower:Travel(destPos)
	if destPos == nil then return end
	self:Clear()
	
	if destPos.IsVector3 and destPos:IsVector3() then -- is a Vector3
		self.dest = destPos
		self.inst:PushEvent("ngl_newdest", {dest = self.dest})
		self:FindPath()
	elseif type(destPos) == "table" then				 
		local steps
		if IsValidPath(destPos) then					-- is a path
			steps = destPos.steps
		elseif #destPos >= 2 then						-- is a steps
			steps = destPos
		end
		
		if steps ~= nil then
			self.dest = StepToVector3(steps[#steps])
			self.path = {steps = steps, currentstep = 2}
			self.inst:PushEvent("ngl_startpathfollow", {path = self.path})
			self.followpath_task = self.inst:DoPeriodicTask(FRAMES, follow_path, 0)
		end
	end

end

-- Deprecated, self-adapte by default and use SetMoveModeOverrideInternal to override it
--function PathFollower:SetMoveMode(movemode)
--	self.movemode = movemode
--end

function PathFollower:HasDest()
	return self.dest ~= nil
end

function PathFollower:GetLocomotor()
	return self.inst.components.locomotor or nil
end


-- stop and reset all the record
function PathFollower:ForceStop()
	self:Clear()
	
	local locomotor = self:GetLocomotor()
	if locomotor then
		locomotor:Stop()
		locomotor:Clear()
	else
		-- differs in different modes
		if self:GetMoveMode(true) == MOVEMODE_DIRECTWALK then
			SendRPCToServer(RPC.StopWalking)
		else
			-- common stop method
			local angle = self.inst:GetRotation() * DEGREES
			local offset_x = math.cos(angle) * FORCESTOP_OFFSET
			local offset_z = -math.sin(angle) * FORCESTOP_OFFSET
			local x,_,z = self.inst:GetPosition():Get()
			
			-- ugly code, just stop via leftclick the pos we front-facing
			SendRPCToServer(RPC.LeftClick, ACTIONS.WALKTO.code, x + offset_x, z + offset_z)
		end
	end
	
	self.inst:PushEvent("ngl_stoppathfollow")
	
end

function PathFollower:Clear()
	local pathfinder = self:GetPathfinder()
	if pathfinder and pathfinder:GetSearchResult() == STATUS_CALCULATING then
		pathfinder:KillSearch()
	end
	
	if self.waitsearchresult_task then
		self.waitsearchresult_task:Cancel()
		self.waitsearchresult_task = nil
	end
	
	if self.followpath_task then
		self.followpath_task:Cancel()
		self.followpath_task = nil
	end
	
	if self.check_arrival_for_directwalk_task then
		self.check_arrival_for_directwalk_task:Cancel()
		self.check_arrival_for_directwalk_task = nil
	end
	
	self.path = nil
	self.dest = nil

	self.last_check_time = 0
	
	if self.debug_signs ~= nil then
		for _, sign in pairs (self.debug_signs) do 
			sign:Remove()
		end
		self.debug_signs = nil
	end	
end

function PathFollower:WaitingForPathSearch()
	return self.waitsearchresult_task ~= nil
end

function PathFollower:FollowingPath()
	return self.followpath_task ~= nil
end

function PathFollower:DirectWalkingWithNoPath()
	return self.check_arrival_for_directwalk_task ~= nil
end

-- pathfind via single pathfinder at once
function PathFollower:FindPath()
	local pathfinder = self:GetPathfinder()
	if self.dest == nil or pathfinder == nil then return end
	
	local p0 = Vector3(self.inst:GetPosition():Get())
	local p1 = Vector3(self.dest:Get())

	p0.y = 0
	p1.y = 0

	pathfinder:SubmitSearch(p0, p1, self:GetPathCaps(), self:GetGroundCaps())
	
	self.waitsearchresult_task = self.inst:DoPeriodicTask(FRAMES, check_search_status, 0)
end

-- get the current pathfinder 
function PathFollower:GetPathfinder()
	return self.pathfinder
end

function PathFollower:SetPathfinder(pathfinder)
	local cmp = self.inst.components[pathfinder]
	if cmp ~= nil then
		self.pathfinder = cmp
	else 
		self.pathfinder = pathfinder
	end
end

function PathFollower:GetArriveStep()
	return self:GetLocomotor() and ARRIVESTEP_MOVEMENTPREDICT_ENABLED or ARRIVESTEP_MOVEMENTPREDICT_DISABLED
end

-- it's very complex to get the actual speed
-- including externalspeedmultiplier, groundmulti, inventoryitem multi and many other multi
-- evenif so ,it's not the actual
function PathFollower:GetSpeed()
	return
end

--- MOVE MODE

-- use for component internal toggle movemode
function PathFollower:SetMoveModeOverrideInternal(movemode)
	self._movemode_override = movemode
end

-- outer interface and with higher priority, note that setmovemodeoverride before the Travel
function PathFollower:SetMoveModeOverride(movemode)
	self.movemode_override = movemode
end

-- should update the movemode after call Self:Move
function PathFollower:UpdateMoveMode()
	--update according to active_item
	-- when active_item , the left action is DROP but not WALKTO,which cause fail to handle LEFTCLICK RPC
	-- so use DIRECTWALK rpc instead
	local active_item = self.inst.replica.inventory and self.inst.replica.inventory:GetActiveItem() or nil
	self.movemode = active_item and MOVEMODE_DIRECTWALK or MOVEMODE_LEFTCLICK
end

-- without_update means you will get the previous movemode, actually it's the movemode of currentstep
-- Match the movemode when Move and Stop, otherwise it may have some problem
function PathFollower:GetMoveMode(without_update)
	if not without_update then
		self:UpdateMoveMode()
	end
	return self.movemode_override or self._movemode_override or self.movemode
end

--function PathFollower:GetMoveModeString()
--	if self.movemode_override then
--		if self.movemode_override == MOVEMODE_LEFTCLICK then
--			return "leftclick mode (0)"
--		elseif self.movemode_override == MOVEMODE_DIRECTWALK then
--			return "directwalk mode (1)"
--		end
--	else
--		return "adaptive mode "
--	end
--end

--- PATH CAPS
function PathFollower:SetPathCapsOverride(pathcaps)
	self.pathcaps_override = pathcaps
end

-- client side Physics modification will apply only when lag compensation enabled
function PathFollower:SetCollideWith(COLLISION_TYPE, clear_collide)
    local old_collision_mask = self.inst.Physics:GetCollisionMask()
    local new_collision_mask = old_collision_mask
        if not clear_collide and not self:CanCollideWith(COLLISION_TYPE) then
            new_collision_mask = self.inst.Physics:GetCollisionMask() + COLLISION_TYPE
        elseif clear_collide and self:CanCollideWith(COLLISION_TYPE) then
            new_collision_mask = self.inst.Physics:GetCollisionMask() - COLLISION_TYPE
        end
    self.inst.Physics:SetCollisionMask(new_collision_mask)
end

-- a function return can player collide with other
-- for example: if we can cross the ocean and land ,then it return false with COLLISION.LAND_OCEAN_LIMITS
function PathFollower:CanCollideWith(COLLISION_TYPE)
-- | COLLISION_TYPE    | MASK_VALUE | BIN_VALUE           |
-- | ----------------- | ---------- | ------------------- |
-- | GROUND            | 32         | 0000 0000 0010 0000 |
-- | BOAT_LIMITS       | 64         | 0000 0000 0100 0000 |
-- | LAND_OCEAN_LIMITS | 128        | 0000 0000 1000 0000 |
-- | LIMITS            | 192        | 0000 0000 1100 0000 |
-- | WORLD             | 224        | 0000 0000 1110 0000 |
-- | ITEMS             | 256        | 0000 0001 0000 0000 |
-- | OBSTACLES         | 512        | 0000 0010 0000 0000 |
-- | CHARACTERS        | 1024       | 0000 0100 0000 0000 |
-- | FLYERS            | 2048       | 0000 1000 0000 0000 |
-- | SANITY            | 4096       | 0001 0000 0000 0000 |
-- | SMALLOBSTACLES    | 8192       | 0010 0000 0000 0000 |
-- | GIANTS            | 16384      | 0100 0000 0000 0000 |

    local collision_mask = self.inst.Physics:GetCollisionMask()
    return BitOperate(collision_mask,COLLISION_TYPE,"and") == COLLISION_TYPE
end

function PathFollower:UpdatePathCaps()
	local isplayer = self.inst:HasTag("player")
	local iswebber = self.inst:HasTag("spiderwhisperer")

    -- get result from Physics component(C++ side) and use bit operate function in bit_operate_util.lua
	local no_land_ocean_limits = not self:CanCollideWith(COLLISION.LAND_OCEAN_LIMITS)
	local no_obstacle_collision = not self:CanCollideWith(COLLISION.OBSTACLES)
	self.pathcaps = {player = isplayer, ignorecreep = true, ignorewalls = no_obstacle_collision, allowocean = no_land_ocean_limits}
end


function PathFollower:GetPathCaps(without_update)
	if not without_update then
		self:UpdatePathCaps()
	end
	return self.pathcaps_override or self.pathcaps
end

--- FASTER GROUND TIELS
--this may cost a lot
local function search_faster_on_tiles(inst)
    local faster_on_tiles = {}
    for tile_name, tile_id in pairs(WORLD_TILES) do
        if TileGroupManager:IsLandTile(tile_id) then
            if inst:HasTag("turfrunner_"..tostring(tile_id)) then
                faster_on_tiles[tostring(tile_id)] = true
            end
        end
    end
    --print("call faster tiles search")
    return faster_on_tiles
end

function PathFollower:UpdateCacheFasterGroundTiles(mount)
    local inst = mount or self.inst
    if self.cache_faster_on_tiles == nil then
        self.cache_faster_on_tiles = {}
    end
    self.cache_faster_on_tiles[inst.prefab] = search_faster_on_tiles(inst)
end


function PathFollower:GetFasterGroundTiles(mount, without_update)
    local inst = mount or self.inst
    if self.cache_faster_on_tiles == nil or self.cache_faster_on_tiles[inst.prefab] == nil and not without_update then
        -- update only has no corresponding record
        self:UpdateCacheFasterGroundTiles(inst)
    end
    return self.cache_faster_on_tiles[inst.prefab]
end

--- GROUND CAPS
function PathFollower:SetGroundCapsOverride(groundcaps)
	self.groundcaps_override = groundcaps
end

-- for astar pathfinder
function PathFollower:UpdateGroundCaps()
	local iswebber = self.inst:HasTag("spiderwhisperer")
-- 	local isghost = self.inst:HasTag("player") and
-- 					(self.inst.player_classified ~= nil and self.inst.player_classified.isghostmode:value()) or
-- 					(self.inst.player_classified == nil and self.inst:HasTag("playerghost"))
-- 	local isriding =(self.inst.replica and self.inst.replica.rider and self.inst.replica.rider._isriding:value()) or
-- 					(self.inst.components and self.inst.components.rider and self.inst.components.rider:IsRiding())
	local mount = (self.inst.player_classified ~= nil and self.inst.player_classified.ridermount:value()) or
	              (self.inst.components and self.inst.components.rider and self.inst.components.rider:GetMount()) or
	              nil
	local isflying = not self:CanCollideWith(COLLISION.LAND_OCEAN_LIMITS)

	self.groundcaps = {speed_on_road = nil, speed_on_creep = nil, faster_on_tiles = nil}

	--ROAD
	if not isflying then
	    if mount ~= nil then
	        local mount_faster_on_road = (self.inst.player_classified ~= nil and self.inst.player_classified.riderfasteronroad:value()) or
                                         (mount.components.locomotor ~= nil and mount.components.locomotor.fasteronroad)
            self.groundcaps.speed_on_road = mount_faster_on_road and ASTAR_SPEED_FASTER or ASTAR_SPEED_NORMAL
	    else
	        -- we can't get locomotor:FasterOnRoad() when lag compensation OFF ,but player always fasteronroad i think
            self.groundcaps.speed_on_road = ASTAR_SPEED_FASTER
        end
	end

	--CREEP(spidernet)
	--ghost not trigger the creep
	if not isflying then
        if mount ~= nil then
            -- webber riding the mount will not trigger the creep either
            self.groundcaps.speed_on_creep = (not iswebber) and ASTAR_SPEED_SLOWER or ASTAR_SPEED_NORMAL
        else
            self.groundcaps.speed_on_creep = iswebber and ASTAR_SPEED_FASTER or ASTAR_SPEED_SLOWER
		end
	end

	--FASTER TILES
    --it 's corresponding to the locomotor.faster_on_tiles
    -- such as wurt --> MARSH
    if not isflying then
        if mount ~= nil then
            self.groundcaps.faster_on_tiles = self:GetFasterGroundTiles(mount)
        else
            self.groundcaps.faster_on_tiles = self:GetFasterGroundTiles(self.inst)
        end
    end
end

function PathFollower:GetGroundCaps(without_update)
	if not without_update then
		self:UpdateGroundCaps()
	end
	return self.groundcaps_override or self.groundcaps
end

--- DEBUG FNS
function PathFollower:GetDebugString()
	
	if self.dest == nil then
		return "no dest"
	else
		local status 
		if self:DirectWalkingWithNoPath() then
			status = "no path and reset to directwalk"
		elseif self:WaitingForPathSearch() then
			status = "waiting for search result"
		elseif self:FollowingPath() then
			status = "following the path"
		end
			
		return "DEST:" .. tostring(self.dest) .. " STATUS:" .. status 
	end
end

function PathFollower:VisualizePath()
	if not IsValidPath(self.path) then return end
	self.debug_signs = {}
	for _,step in pairs (self.path.steps) do 
		local sign = SpawnPrefab("minisign")
		sign.Transform:SetPosition(step.x, step.y, step.z)

		table.insert(self.debug_signs, sign)
	end
end

function PathFollower:SetDebugMode(enabled)
	self.debugmode = (enabled == true)
	if self:FollowingPath() then
		self:VisualizePath()
	end
end

local function find_closest_prefab_exclude_list(x, y, z, rad, prefab, list)	
    local ents = TheSim:FindEntities(x,y,z, rad or 30)
    local closest = nil
    local closeness = nil
    for k,v in pairs(ents) do
        if v.prefab == prefab then
			local vx,vy,vz = v:GetPosition():Get()
            if (closest == nil or (closeness and VecUtil_DistSq(x,z, vx,vz) < closeness)) and not v:HasTag("ngl_scaned") then
                closest = v
                closeness = VecUtil_DistSq(x,z, vx,vz)
            end
        end
    end
    if closest then
        table.insert(list, closest)
		closest:AddTag("ngl_scaned")
		--print("found", closest.GUID, " add to pathsteps")
		-- call by recursion
		local cx,cy,cz = closest:GetPosition():Get()
		find_closest_prefab_exclude_list(cx, cy, cz, rad, prefab, list)
    end
end

-- generate steps via seeking for the nearest prefab
function PathFollower:GenerateStepsByPrefab(prefab, rad, without_travel)
	local found_prefabs = {}
	local x,y,z = self.inst:GetPosition():Get()
	find_closest_prefab_exclude_list(x, y, z, rad, prefab, found_prefabs)
	
	if #(found_prefabs) == 0 then return end
	
	--first step is my position
	local exported_steps = {{x = x,y = y,z = z}}
	for _,v in pairs(found_prefabs) do
		local vx,vy,vz = v:GetPosition():Get()
		table.insert(exported_steps, {x=vx, y=vy, z=vz})
		v:RemoveTag("ngl_scaned")
	end
	
	if not without_travel then
		self:Travel(exported_steps)
	end
	return exported_steps
end

return PathFollower