
-- the status of pathsearch
local STATUS_CALCULATING = 0
local STATUS_FOUNDPATH = 1
local STATUS_NOPATH = 2

local Pathfinder = Class(function(self, inst)
	self.inst = inst
	
	self.handle = nil
end)

function Pathfinder:SubmitSearch(startPos, endPos, pathcaps)
	self.handle = TheWorld.Pathfinder:SubmitSearch(startPos.x, startPos.y, startPos.z, endPos.x, endPos.y, endPos.z, pathcaps)
end


function Pathfinder:GetSearchStatus()
	return self.handle and TheWorld.Pathfinder:GetSearchStatus(self.handle)
end

function Pathfinder:GetSearchResult()
	return self.handle and TheWorld.Pathfinder:GetSearchResult(self.handle)
end

function Pathfinder:KillSearch()
	if self.handle then
		TheWorld.Pathfinder:KillSearch(self.handle)
	end
end

function Pathfinder:CheckCursorWalkable(pathcaps)
	if ThePlayer and TheInput and TheWorld then
		local pt = ThePlayer:GetPosition()
		local ct = TheInput:GetWorldPosition()
		return TheWorld.Pathfinder:IsClear(pt.x, pt.y, pt.z, ct.x, ct.y, ct.z, pathcaps)
	end
end

return Pathfinder