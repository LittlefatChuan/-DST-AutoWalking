
-- Thanks for the tutorial of A Star : https://www.redblobgames.com/pathfinding/a-star/introduction.html
-- And a very nice article： https://www.gamedev.net/reference/articles/article2003.asp
-- 他的中文译版： https://blog.csdn.net/kenkao/article/details/5476392
-- And the Coordinate system of trailblazer mod： https://steamcommunity.com/sharedfiles/filedetails/?id=810372558
-- Written by 川小胖


---------------------
-- For DebugPrint  --
---------------------
local DEBUG_MODE = false

local function DebugPrint(...)
	if DEBUG_MODE then
		return print(...)
	end
end
---------------------
-- Local Variables --
---------------------
-- define of groundtile speed multiplier
local ASTAR_SPEED_FASTER = 1
local ASTAR_SPEED_NORMAL = 0
local ASTAR_SPEED_SLOWER = -1

-- cost multi of groundtile
local ASTAR_COSTMULTI_FASTER = 0.5
local ASTAR_COSTMULTI_NORMAL = 1
local ASTAR_COSTMULTI_SLOWER = 5

-- 栅格/采样节点的距离间隔
-- Distance between pathfinding nodes
local PATH_NODE_DIST = 4
local PATH_NODE_DIST_SQ = PATH_NODE_DIST * PATH_NODE_DIST

-- 最大的工作量（即一共访问的点数量），达到后强制停止寻路
-- pathfinding will forcestop when it reach the max work amount
local PATH_MAX_WORK = 15000
---------------------
-- Local Functions --
---------------------

-- 返回一个基于玩家位置为原点的2D相对位置坐标，单位长度为PATH_NODE_DIST
-- Makes a 2int coordinate
-- @param x : x val of coordinate
-- @param y : y val of coodinate
-- @return  : 2int coordinate table:
--       .x : x val of coordinate
--       .y : y val of coordinate
--       .f_score : g_score + h_score
local makeCoord = function(x, y, f_score)
	return 	{
				x = x,
				y = y,
				f_score = f_score or 0
			}
end

-- 基于玩家原点的相对坐标转换为世界中的绝对位置
-- Converts a 2int coordinate to Vector3
-- @param origin : The origin of the coordinate system
-- @param coord  : coordinate to convert
-- @return       : the Vector3 in world space corresponding to the given coordinate
local coordToPoint = function(origin, coord)
	return Vector3	(
						origin.x + (coord.x * PATH_NODE_DIST),
						0,
						origin.z + (coord.y * PATH_NODE_DIST)
					)
end

-- 世界位置 转换为 Step类型 （元素分别为y，x，z 的表结构）
-- Vector3 --> {y,x,z}
local pointToStep = function(point)
	return {y = point.y, x = point.x, z = point.z}
end

-- Step类型 转为 世界位置
-- {y,x,z} --> Vector3
local stepToPoint = function(step)
	return Vector3(step.x, step.y, step.z)
end

-- 保持开放序列从小到大有序，查找合适的位置插入到序列
-- insert to the openlist and keep the list sorted meanwhile
local pushIntoOpenList = function(search, coord)
	local frontier = search.frontier
	if #frontier == 0 then -- 如果没有元素，则直接插入
		table.insert(search.frontier, coord)
	else	-- 否则，查找插入的位置，保持从小到大有序状态
		for i=1, #(frontier) do 
			if coord.f_score < frontier[i].f_score then
				table.insert(search.frontier, i, coord)
				return
			end
		end
		table.insert(search.frontier, coord) 
	end
end

-- 因为序列已经是有序的，因此第一个元素就是最小F值的坐标
-- since the openlist has been sorted ,just return the first coord which is the min F scores coord
local popFromOpenList = function(search)
	-- 已经是有序的，所以直接返回第一个元素即是最小F值的
	local frontier = search.frontier 
	if frontier and #(frontier) > 0 then 
		local best = frontier[1]
		table.remove(search.frontier, 1)
		return best
	else
		DebugPrint("[A STAR PATHFINDER] : " .. "no element in openlist!")
	end
end


-- Deprecated, use pushIntoOpenList and popFromOpenList instead will be more effective, i think
-- 取得OpenList的最小F值的相对坐标，目前用的是遍历，不知道有没有别的方法能够优化，排序之类的？
-- Get the priority/min F value coord from the frontier(OpenList)
local getBestCoord = function(search)
	local frontier = search.frontier
	local best = nil 
	local index = 0
	for i=1,#(frontier) do 
		if best == nil or frontier[i].f_score < best.f_score then
			best = frontier[i]
			index = i
		end
	end
	
	if index > 0 then
		table.remove(search.frontier, index)
		--DebugPrint("[A STAR PATHFINDER] : " .. "pop coord, number: "..index)
	else 
		DebugPrint("[A STAR PATHFINDER] : " .. "pop coord error！！！")
	end
	return best
end

-- 是否已经访问了这个坐标
-- Return true if we visited/tracked this coord , otherwise false
local visited = function(search, coord)
	if search.g_score_so_far[coord.x] == nil then
		search.g_score_so_far[coord.x] = {}
	end
	if search.direction_so_far[coord.x] == nil then
		search.direction_so_far[coord.x] = {}
	end
	return search.g_score_so_far[coord.x][coord.y] == nil
	
end

-- 计算损失值，哈夫曼距离主要用于4方向，对角线距离用于8方向
-- calc the cost of G scores and F scores , F = G + H
-- when we consider four directions ,better to use Manhattan distance
-- when we consider eight directions ,better to use Diagnol distance
local calcCost = function(p1, p2)
	-- Manhattan distance
	--return math.abs(p1.x - p2.x) + math.abs(p1.z - p2.z)
	
	-- Diagnol distance 
	local dx = math.abs(p1.x - p2.x)
	local dz = math.abs(p1.z - p2.z)
	local min_xz = math.min(dx,dz)
	return dx + dz - 0.5 * min_xz  --0.5 means is approximately equal to (2- sqrt(2))
end


-- 计算地面速度乘数，通过减小在卵石路上的G值可以优先考虑卵石路上的点，达到跟随卵石路的效果
-- 同样通过增大蜘蛛网上的G值可以尽量避免走到蜘蛛网上，（Webber则是加速）
local calcGroundSpeedMulti = function(point, groundcaps)
    --NO GROUNDCAPS SETTINGS
    if groundcaps == nil then return ASTAR_COSTMULTI_NORMAL end

    --CREEP
    if groundcaps.speed_on_creep ~= nil then
        local is_oncreep = TheWorld.GroundCreep:OnCreep(point.x, 0, point.z)
        -- dont go through the creep to avoid trigger the net evenif it's on road or faster tiles
        if is_oncreep then
            if groundcaps.speed_on_creep < ASTAR_SPEED_NORMAL then
                return ASTAR_COSTMULTI_SLOWER
            elseif groundcaps.speed_on_creep > ASTAR_SPEED_NORMAL then
                return ASTAR_COSTMULTI_FASTER
            end
        end
    end

    --ROAD
    if groundcaps.speed_on_road ~= nil then
        local is_onroad = RoadManager ~= nil and RoadManager:IsOnRoad(point.x, 0, point.z) or
                            TheWorld.Map:GetTileAtPoint(point.x, 0, point.z) == WORLD_TILES.ROAD
        if is_onroad then
            -- nobody will walk slower on road but just in case
            if groundcaps.speed_on_road < ASTAR_SPEED_NORMAL then
                return ASTAR_COSTMULTI_SLOWER
            elseif groundcaps.speed_on_road > ASTAR_SPEED_NORMAL then
                return ASTAR_COSTMULTI_FASTER
            end
        end
    end
    --FASTER TILES
    if groundcaps.faster_on_tiles ~= nil then
        local tile = TheWorld.Map:GetTileAtPoint(point.x, 0, point.z)
        if groundcaps.faster_on_tiles[tostring(tile)] then
            return ASTAR_COSTMULTI_FASTER
        end
    end
    return ASTAR_COSTMULTI_NORMAL
end

-- 计算地面速度乘数，通过减小在卵石路上的G值可以优先考虑卵石路上的点，达到跟随卵石路的效果
-- 同样通过增大蜘蛛网上的G值可以尽量避免走到蜘蛛网上，（Webber则是加速）
-- less cost of G scores in road and more cost in creep(creep means spider web which slows down your movespeed,except webber can speed up)
-- then we can follow the road and avoid the spider web as possible
-- local calcGroundSpeedMulti = function(is_onroad, is_oncreep, groundcaps)
-- 	local multi = 1
-- 	if is_onroad and groundcaps.speed_on_road then
-- 		multi = multi * ((groundcaps.speed_on_road > 0 ) and ASTAR_COSTMULTI_FASTER or ASTAR_COSTMULTI_SLOWER)
-- 	end
--
-- 	if is_oncreep and groundcaps.speed_on_creep then
-- 		multi = multi * ((groundcaps.speed_on_creep > 0) and ASTAR_COSTMULTI_FASTER or ASTAR_COSTMULTI_SLOWER)
-- 	end
--
-- 	return multi
-- end

-- 计算方向变化乘数，方向变化的点损失值更大，从而达到平滑路径的效果
-- less cost of G scores in same direction and more cost in different direction 
-- it's another method to smooth the path
local calcDirectionMulti = function(nextCoord_direct, currentCoord_direct)
    --return 1
	return (1 * (nextCoord_direct == currentCoord_direct and 1 or 2))
end

-- 避开障碍物的一个测试：隔壁单机豹卷风的吸入判定函数，但是每个点都查找障碍物每个判定，距离长的时候消耗也忒大了
-- for avoid obstacles ,but it cost so much resource when request a long-distance pathfind, Do not use it frequently
local CheckLOSFromPoint = function(pos, target_pos, blockers)
	if DEBUG_MODE == false then return false end
	
    local dist = target_pos:Dist(pos)
    local vec = (target_pos - pos):GetNormalized()
	
    local ents = blockers or TheSim:FindEntities(pos.x, pos.y, pos.z, dist, {"blocker"})

    for k,v in pairs(ents) do
		if v.Physics:IsActive() then
			local blocker_pos = v:GetPosition()
			local blocker_vec = (blocker_pos - pos):GetNormalized()
			local blocker_perp = Vector3(-blocker_vec.z, 0, blocker_vec.x)
			local blocker_radius = v.Physics:GetRadius()
			blocker_radius = math.max(0.75, blocker_radius)

			local blocker_edge1 = blocker_pos + Vector3(blocker_perp.x * blocker_radius, 0, blocker_perp.z * blocker_radius)
			local blocker_edge2 = blocker_pos - Vector3(blocker_perp.x * blocker_radius, 0, blocker_perp.z * blocker_radius)

			local blocker_vec1 = (blocker_edge1 - pos):GetNormalized()
			local blocker_vec2 = (blocker_edge2 - pos):GetNormalized()

		   
			-- print("Checking LoS With:", v)
			local function isbetween(tar, vec1, vec2)
				return ((vec2.x - vec1.x) * (tar.z - vec1.z) - (vec2.z - vec1.z)*(tar.x-vec1.x)) > 0
			end

			if isbetween(vec, blocker_vec1, blocker_vec2) then
				-- print(v, "blocks LoS.")
				return false
			end
		end
    end
    -- print("Nothing blocked LoS.")

    return true
end

-- 陆地和浅海交界处，浅海地皮会伸出 1/4区域 的陆地，overhang区因为算浅海地皮，和陆地没有LOS
-- overhang area means the extend area that near the shallow ocean, it's belong as shallow ocean tile
local IsOverhangAtPoint = function(x, y, z)
	if type(x) == "table" and x.IsVector3 ~= nil and x:IsVector3() then
		x, y, z = x:Get()
	end
	return not TheWorld.Map:IsAboveGroundAtPoint(x, y, z) and TheWorld.Map:IsVisualGroundAtPoint(x, y, z)
end

-- check the LOS and potiental LOS
local function CheckWalkableFromPoint(pos, target_pos, pathcaps)
	--function IsClear don't consider the void tile in cave
	--when you have no limit of land and ocean ,it will return false ,but actually you can pass it
    if pos == target_pos  or (pathcaps ~= nil and pathcaps.allowocean) then
        return true
    end

	local hasLOS = TheWorld.Pathfinder:IsClear(
													pos.x, pos.y, pos.z,
													target_pos.x, target_pos.y, target_pos.z,
													pathcaps
												)
	if hasLOS == true then
		return true
	end

	--------- POTIENTAL WALKABLE WITH ONLY DIAGONAL TILE CONNECTION ------------
	-- https://forums.kleientertainment.com/forums/topic/147232-the-issue-about-pathfinderisclear-on-tile-connection-in-diagonal-direction/
	-- when the points in diagonal tile connection,IsClear return false
	-- they can be actually walk through,so we should take account of it

	-- ** it's only fit for PATH_NODE_DIST = 4 so far

	-- checkLOS = checkTile + checkWalls, i think it is
	-- 1.check land tiles
	local is_both_lands = TheWorld.Map:IsVisualGroundAtPoint(pos.x, pos.y, pos.z) and
							TheWorld.Map:IsVisualGroundAtPoint(target_pos.x, target_pos.y, target_pos.z)
	if not is_both_lands then
		return false, "not both in land"
	end
	
	-- 2.check adjacent tiles
	local tile_x1, tile_y1 = TheWorld.Map:GetTileCoordsAtPoint(pos.x, pos.y, pos.z)
	local tile_x2, tile_y2 = TheWorld.Map:GetTileCoordsAtPoint(target_pos.x, target_pos.y, target_pos.z)
	local is_adjacent = (math.abs(tile_x1 - tile_x2) <= 1) and (math.abs(tile_y1 - tile_y2) <= 1)
	
	if not is_adjacent then
		return false, "no adjacent tiles"
	end
	
	--3.take some samples point and check if is on land
	--check some point to ensure the connection between adjacent tiles
	local is_sampledpos_land = true
	for i = 1, 3, 1 do
		local checkPos = Lerp(pos, target_pos, i*0.25)
		if is_sampledpos_land and not TheWorld.Map:IsVisualGroundAtPoint(checkPos:Get()) then
			is_sampledpos_land = false
			break
		end
	end

	if not is_sampledpos_land then
		return false, "not all samples pos land"
	end
	
	-- 4.check haswalls
	local is_overhang = IsOverhangAtPoint(pos:Get()) or IsOverhangAtPoint(pos:Get())
	local world_has_ocean = TheWorld.has_ocean
	
	-- when player is considered off land when stand on overhang point 
	-- and in world has not ocean(eg: the cave),IsClear function return false evenif allowocean  	
	local passed_checkwalls = is_overhang and not world_has_ocean

	if not passed_checkwalls then
		-- set allowocean to check walls individually
		local virtual_pathcaps = shallowcopy(pathcaps)
		virtual_pathcaps.allowocean = true
		virtual_pathcaps.ignorewalls = false

		local is_no_walls = TheWorld.Pathfinder:IsClear(
							pos.x, pos.y, pos.z,
							target_pos.x, target_pos.y, target_pos.z,
							virtual_pathcaps
						)
		if not is_no_walls then
			return false, "has walls blocked"
		end
	end
	
	--5.CheckLOSFromPoint(pos, target_pos) 
	
	
	return true
end

-- 构建路径，从末尾节点向前遍历camefrom链表，其中只有方向不同的点才会插入到路径中，可以简化路径
-- Constructs a path from a finishedPath
-- @param search 	   : The search you request, which contains the params of pathfinding 
-- @param finalCoord   : The finalCoord that close the dest,but not the dest
-- @return             : The same path, stored in native format
local makePath = function(search, finalCoord)
	-- Convert came_from to the path 
	-- Structure: table
	-- .steps
	--       .1.y = 0
	--       .1.x = <x value>
	--       .1.z = <z value>
	--       ...
	
	-- construct path part
    -- be careful don't put step table of the same value into steps ,otherwise theplayer will goto the void with position -1.#J
	local path = { steps = { } }
	-- the nearest point to dest
	local finalPoint = coordToPoint(search.startPos, finalCoord)
	table.insert(path.steps, pointToStep(search._endPos))
	if search.endPos ~= search._endPos and not CheckWalkableFromPoint(finalPoint, search._endPos, search.pathcaps) then
	    table.insert(path.steps, pointToStep(search.endPos))
	end

	local lastDirection = finalPoint - search.endPos
	local currentCoord = finalCoord
	local lastCoord = currentCoord
	while(currentCoord.x ~= 0 or currentCoord.y ~= 0) do -- util the startcoord (0,0)
		local currentDirection = search.direction_so_far[currentCoord.x][currentCoord.y]
		-- In order to simplify the path, only the steps with different direction will be added
		if currentDirection ~= lastDirection   then
			local worldPoint = coordToPoint(search.startPos, currentCoord)
			--local point = Vector3(worldVec:Get()) It's Wrong!
			-- Notice: the step is a table of {y,x,z}, not Vector3
			-- to stay the same with klei's pathfinding result format
			local step = pointToStep(worldPoint)
			table.insert(path.steps, step)
		end
		lastDirection = currentDirection
		lastCoord = currentCoord
		currentCoord = search.came_from[currentCoord]
	end
	-- CurrentCoord == startCoord(0,0) when reach here 
	local pointNextStartPos = coordToPoint(search.startPos, lastCoord)
	if search._startPos ~= search.startPos and not CheckWalkableFromPoint(search._startPos, pointNextStartPos, search.pathcaps) then
		table.insert(path.steps, pointToStep(search.startPos))
	end
	table.insert(path.steps, pointToStep(search._startPos))
	path.steps = table.reverse(path.steps) -- klei has write it down in the util.lua
	
	return path
end


-- 另一种平滑路径的方法，在构建完路径后跑一遍，每三个点两头hasLos，则中间点为非必要点
-- a method to smooth the path via run through the path and check LOS between points
-- remove the unneccessary points which has LOS ,except the points on the road
local smoothPath = function(search)
	-- smooth path part
	-- ie: {0,0}, {0,2}, {3,2} -> {0,0}, {3,2} (given LOS)
	
	
	local path = search.path
	local index = 2
	while(index < #(path.steps)) do
    
		-- Points to test
		local pre = path.steps[index-1]
		local post = path.steps[index+1]
		local current = path.steps[index]

		local prePoint, currentPoint, postPoint = stepToPoint(pre), stepToPoint(current), stepToPoint(post)
		local is_on_speedup_turf = calcGroundSpeedMulti(currentPoint, search.groundcaps) == ASTAR_COSTMULTI_FASTER
		--local is_on_speeddown_turf 
		local virtual_pathcaps = shallowcopy(search.pathcaps)

		-- reset the ignorecreep = false , to test whether the point can help me avoid the creep
		if search.groundcaps.speed_on_creep and search.groundcaps.speed_on_creep < 0 then
			virtual_pathcaps.ignorecreep = false
		end

		
        -- dont remove the points that on speedup_turf even if they're have LOS with last point
		if CheckWalkableFromPoint(prePoint, postPoint, virtual_pathcaps) and
			 (not is_on_speedup_turf ) then -- Has LOS
			table.remove(path.steps, index)
		else -- No LOS
			index = index + 1
		end
	end
	return path

end



-- 找自身和附近地皮的Walkable中心点
-- find the walkable center point  from self tile and nearby tiles
-- to avoid the situation when point is overhang that hasnoLOS with any other points
local function FindWalkableCenterPoint(point, pathcaps)
	local x, y, z = point:Get()
	local is_landtile = TheWorld.Map:IsVisualGroundAtPoint(x, y ,z)
	if not is_landtile then return nil end

	--local is_overhang = is_landtile and not TheWorld.Map:IsAboveGroundAtPoint(x, y, z)
	--local with_checklos = not is_overhang

	-- consider the origin tile first
	local originTileCenterPoint = Vector3(TheWorld.Map:GetTileCenterPoint(x, y, z))
	if CheckWalkableFromPoint(point, originTileCenterPoint, pathcaps) then
		return originTileCenterPoint
	end

	-- consider neighbor tiles next
	for dx= -1, 1 ,1 do
		for dz = -1, 1, 1 do
			local candidateTileCenterPoint = originTileCenterPoint+Vector3(dx, 0, dz)*TILE_SCALE
			if CheckWalkableFromPoint(point, candidateTileCenterPoint, pathcaps) then
				return candidateTileCenterPoint
			end
		end
	end
    print("no fitable point")
    --TODO: still no fitable point in cave
	-- no fitable point
	return nil
end
------------------------
-- External Functions --
------------------------

-- 请求一个搜索，参数为起点，终点，路径设置（ignorecreep = true 指忽视即可以穿过蜘蛛网）和特殊地面设置（卵石路上和蛛网的速度变化，false则不考虑）
-- 搜索中包含了路径的信息，和用于寻路的一些初始变量
-- @param startPos : A Vector3 containing the starting position in world units
-- @param endPos   : A Vector3 continaing the ending position in world units
-- @param pathcaps : (Optional) the pathcaps to use for pathfinding
-- @param groundcaps: (Optional) whether movement speed get changed in road /in creep (spider-web)
-- @return         : A partial path object
--                 .path : If path is finished via LOS, this will be populated, otherwise nil
local requestSearch = function(startPos, endPos, pathcaps, groundcaps)
	
	----------------------
	-- Store parameters --
	----------------------
	local search = { }

	-- if we set the dest at ocean, it has a large probability to fail to pathfind and reach max work amount
	-- it's a big waste of resource, we should avoid it
	-- 如果点到海洋则大概率遍历到最大次数然后中止，这样没必要且很费资源，所以预先判断一下直接设成no path
	--if not TileGroupManager:IsLandTile(TheWorld.Map:GetTileAtPoint(endPos:Get())) then
    if not (
            TheWorld.Map:IsVisualGroundAtPoint(startPos:Get()) and
	        TheWorld.Map:IsVisualGroundAtPoint(endPos:Get())
	        ) then
		search.path = {}
		return search
	end
	-- perserve the real start and end position
    search._startPos = startPos
    search._endPos = endPos

    -- try to standardization
    -- there'll be some issue without standardization in some case ,such as when the points in diagonal tile connection
    -- in some other case it failed to standardization and maybe okay to pathfinding with origin point
	
	search.startPos = FindWalkableCenterPoint(startPos, pathcaps) or search._startPos
	search.endPos   =  search._endPos

	-- LOS parameter
	if pathcaps == nil then
		search.pathcaps = { player = true, ignorecreep = true} -- i have set the creep penalty factor in astar_util
	else
		search.pathcaps = shallowcopy(pathcaps)
		search.pathcaps.ignorecreep = true

	end
	
	if groundcaps == nil then
		search.groundcaps = {speed_on_road = nil, speed_on_creep = nil} -- nil means not consider road and creep
	else
		search.groundcaps = shallowcopy(groundcaps)
	end
	-------------------------
	-- Prepare Pathfinding --
	-------------------------
	
	-- 就算是HasLos，我们也应该处理一下让它尽可能顺着卵石路走
	-- we should process it to follow the road even if it has LOS yet
	
	
	-- Has LOS, return line
	-- if TheWorld.Pathfinder:IsClear	(
											-- search.startPos.x, search.startPos.y, search.startPos.z,
											-- search.endPos.x,   search.endPos.y,   search.endPos.z,
											-- search.pathcaps
										-- )
	-- then
		-- -- just walk straight
		-- search.path = {steps = {pointToStep(startPos), pointToStep(endPos)}}
		
	-- else
		-- No LOS, prepare pathfinding
		

		
		
		
		-- search variable init
		search.frontier = { } 			-- 1 dim array, coord as element
		search.g_score_so_far = { }		-- 2 dim array, coord's x,y as index, number as element
		search.direction_so_far = { }	-- 2 dim array, coord's x,y as index, Vector3 as element
		search.came_from = { }			-- linkedlist , coord as element
		
		search.path = nil
		table.insert(search.frontier, makeCoord(0,0,0))
		search.g_score_so_far[0]={}
		search.g_score_so_far[0][0] = 0
		
		search.direction_so_far[0]={}
		search.direction_so_far[0][0] = Vector3(0,0,0)
		-- search info init
		search.totalWorkDone = 0
		search.startTime = GetTime()
	--end
	
	return search
end

-- 处理搜索，放在PeriodicTask或者OnUpdate，输入是每轮的最大处理量，
-- 如果找到返回true，结果放在search.path里
-- 如果运行到超过最大量则返回false，因此应该放在PeroidicTask或者OnUpdate里，反复继续上次的执行，这种少量分次运行应该能更好处理中止
-- @param search 		 : The search to finish (request one via requestSearch)
-- @param workPerRound   : The number of point track pertime
-- @param maxWork        : The search will process util reach the maxWork amount
-- @return    			 : true if search is over (path == nil means not found path, path is valid means we found it), false if reach the workPerRound you set
local processSearch = function(search, workPerRound, maxWork)

	-- Path already found, return
	if search.path ~= nil then
		return true
	end
	
	-- Cache parameters
	local origin = search.startPos
	
	-- Paths processed this run
	local workDone = 0
	
	-- Process until finished (no search.frontier remain or a path is found)
	while #search.frontier > 0 do
		
		-- get the coord of min F value
		local currentCoord = popFromOpenList(search)
		local currentPoint = coordToPoint(origin, currentCoord)
		
		---------------------------------
		-- Successed in Pathfinding !! --
		---------------------------------
		--pathfinding finish
		if CheckWalkableFromPoint(currentPoint, search.endPos, search.pathcaps)
				and calcCost(currentPoint, search.endPos) <= PATH_NODE_DIST then
			
			DebugPrint("[A STAR PATHFINDER] : " .. "start generate path！")
			search.path = makePath(search, currentCoord)
			
			-- use another smooth method already, we penalize nodes where there is a change of direction
			-- see function calcDirectionMulti
			search.path = smoothPath(search)
			
			-- update info
			search.endTime = GetTime()
			search.costTime = search.endTime - search.startTime
			DebugPrint("[A STAR PATHFINDER] : " .. "finish pathfinding !, cost time: " .. search.costTime .. ",tracked points :" .. search.totalWorkDone )
			return true
		end
		
			-- Candidate points, 8 directions
			local candidatePoints = 	{
											makeCoord(currentCoord.x    , currentCoord.y + 1),							
											makeCoord(currentCoord.x + 1, currentCoord.y	),
											makeCoord(currentCoord.x 	, currentCoord.y - 1),
											makeCoord(currentCoord.x - 1, currentCoord.y 	),
											makeCoord(currentCoord.x + 1, currentCoord.y + 1),
											makeCoord(currentCoord.x - 1, currentCoord.y - 1),
											makeCoord(currentCoord.x + 1, currentCoord.y - 1),
											makeCoord(currentCoord.x - 1, currentCoord.y + 1)
											
											
										}
			
			--local blockers = TheSim:FindEntities(currentPoint.x, currentPoint.y, currentPoint.z, 1.5 * PATH_NODE_DIST, {"blocker"})
			-- Process Candidates
			for point=1,8,1 do
			--for point=1,4,1 do 
				local nextCoord = candidatePoints[point]
				local nextPoint = coordToPoint(origin, nextCoord)
			
				if CheckWalkableFromPoint(currentPoint, nextPoint, search.pathcaps)
					--and CheckLOSFromPoint(currentPoint, nextPoint, blockers)
				then
												
					-- Update G scores
					
					-- walk on the road first and on the creep last
-- 					local is_onroad = search.groundcaps.speed_on_road and (RoadManager ~= nil and RoadManager:IsOnRoad(nextPoint.x, 0, nextPoint.z) or TheWorld.Map:GetTileAtPoint(nextPoint.x, 0, nextPoint.z) == WORLD_TILES.ROAD) or false
-- 					local is_oncreep = search.groundcaps.speed_on_creep and (TheWorld.GroundCreep:OnCreep(nextPoint.x, 0, nextPoint.z)) or false
-- 					local is_on_faster_tiles = search.groundcaps.faster_on_tiles and search.groundcaps.faster_on_tiles[tostring(TheWorld.Map:GetTileAtPoint(nextPoint.x, 0, nextPoint.z))]

					local new_direction = (nextPoint - currentPoint):GetNormalized()
					local new_cost = search.g_score_so_far[currentCoord.x][currentCoord.y] +  calcCost(currentPoint, nextPoint) * calcGroundSpeedMulti(nextPoint, search.groundcaps) * calcDirectionMulti(new_direction, search.direction_so_far[currentCoord.x][currentCoord.y])
					
					--local new_cost = search.g_score_so_far[currentCoord.x][currentCoord.y] +  PATH_NODE_DIST 
					
					if visited(search, nextCoord) or new_cost < search.g_score_so_far[nextCoord.x][nextCoord.y] then
						
						search.g_score_so_far[nextCoord.x][nextCoord.y] = new_cost
						search.direction_so_far[nextCoord.x][nextCoord.y] = new_direction
						nextCoord.f_score = new_cost + calcCost(nextPoint, search.endPos)
						--DebugPrint("[A STAR PATHFINDER] : " .. "f: "..nextCoord.f_score)
						pushIntoOpenList(search, nextCoord)
						search.came_from[nextCoord] = currentCoord
						
						--DebugPrint("[A STAR PATHFINDER] : " .. string.format("(%d,%d)-->(%d,%d)",currentCoord.x,currentCoord.y,nextCoord.x,nextCoord.y))
						
						-- Update work done
						workDone = workDone + 1
					end
				-- else
					-- visited(search, nextCoord)
					-- search.g_score_so_far[nextCoord.x][nextCoord.y] = math.huge
				end
			end
			
			
			-- Check work
			if workDone > workPerRound then
				search.totalWorkDone = search.totalWorkDone + workDone
				-- if reach the max work , just give up 
				if search.totalWorkDone < (maxWork or PATH_MAX_WORK) then
					return false	-- another try in next round
				else 
					DebugPrint("[A STAR PATHFINDER] : " .. "forcestop because max tracked amount reached, we have tracked points:" .. search.totalWorkDone)
					return true		-- too many tries, forcestop
				end
			end
	end
	
	----------------------------
	-- Fail in Pathfinding !! --
	----------------------------
	
	-- No path found ,it happens when you didn't set a max work and it will track all the map.
	if search.path == nil then
		DebugPrint("[A STAR PATHFINDER] : " .. "we have tracked all the map! no path found !")
		return true
	end
		

	
end

return
{
	requestSearch = requestSearch,
	processSearch = processSearch,
	CheckWalkable = CheckWalkableFromPoint
}