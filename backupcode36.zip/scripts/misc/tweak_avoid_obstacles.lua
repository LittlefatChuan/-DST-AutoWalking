local function is_included(inst)
	return 	inst:HasTag("blocker") and inst.Physics
		 and (
		 inst:GetPhysicsRadius(0) > .5 
			--4 stuffs that player prefers to use in blocking
		or	inst.prefab == "homesign" 
		or	inst.prefab == "fossil_stalker" 
		or	inst.prefab == "lureplant"	
		--or	string.sub(inst.prefab,1,11) == "chesspiece_" 
		--or (inst.components.heavyobstaclephysics ~= nil or inst:HasTag("heavy")
		)
		and not inst:HasTag("heavy")
end
local function sayfortest(str)
	if not TheWorld.ismastersim then
		local talker = ThePlayer.components.talker
		if talker then
			talker:Say(str)
		end
	end
		
end

local heavyblocker_equipped = nil

local function add_heavy_equip_listener(player)
	player:ListenForEvent("equip",function (player, data)
							if data.item == nil then return end
							local pfwall = data.item.components.ngl_obstaclepfwall
							if pfwall ~= nil then
								pfwall.equip_task = pfwall.inst:DoTaskInTime(0.5,function()
									pfwall:RemoveWallSafely()
									pfwall.equip_task = nil
									heavyblocker_equipped = data.item
									--sayfortest(heavyblocker_equipped.prefab)
								end)
								
								
							end
						end)
						
	player:ListenForEvent("unequip",function (player, data)
							if heavyblocker_equipped == nil then return end
							local pfwall = heavyblocker_equipped.components.ngl_obstaclepfwall
							if pfwall ~= nil then
								pfwall.unequip_task = pfwall.inst:DoTaskInTime(0.5,function()
									pfwall:AddWallSafely()
									pfwall.unequip_task = nil
									heavyblocker_equipped = nil
								end)
								
							end
						end)

end

AddPrefabPostInitAny(function (inst)
	if is_included(inst) and inst.components.ngl_obstaclepfwall == nil then
		inst:AddComponent("ngl_obstaclepfwall")
	end

end)

--AddPlayerPostInit(add_heavy_equip_listener)