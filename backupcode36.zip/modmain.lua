GLOBAL.setmetatable(env, {__index = function(t, k) return GLOBAL.rawget(GLOBAL, k) end})
if TheNet:IsDedicated()  then  return end

-------------------ASSETS----------------------------
local is_newicon = GetModConfigData("ICON_STYLE") > 0

-- path line
line_xml = "images/line.xml"
line_tex = "images/line.tex"
line_texName = string.sub(line_tex, string.find(line_tex, "[^/]*$")) -- "line.tex"
-- dest icon
icon_xml = is_newicon and "images/mappin.xml" or "images/mappin_old.xml"
icon_tex = is_newicon and "images/mappin.tex" or "images/mappin_old.tex"
icon_texName = string.sub(icon_tex, string.find(icon_tex, "[^/]*$")) -- "mappin.tex"

Assets = {
    Asset("ATLAS", line_xml),
	Asset("IMAGE", line_tex),
	
    Asset("ATLAS", icon_xml),
	Asset("IMAGE", icon_tex)
}


------------------COMPONENTS REGISTER-----------------
local PATHFINDER = GetModConfigData("PATHFINDER")
local pathfinder = nil

AddPlayerPostInit(function(player)
	-- add astar pathfinder
	if player.components.ngl_astarpathfinder == nil then
		player:AddComponent("ngl_astarpathfinder")
	end
	
	-- add official pathfinder
	if player.components.ngl_pathfinder == nil then
		player:AddComponent("ngl_pathfinder")
	end
	if player.components.ngl_pathfollower == nil then
		player:AddComponent("ngl_pathfollower")
	end
	
	if PATHFINDER == "klei's" then
		pathfinder = player.components.ngl_pathfinder
	else
		pathfinder = player.components.ngl_astarpathfinder
	end
	player.components.ngl_pathfollower:SetPathfinder(pathfinder)
	
	-- override for island adventure mod
	if TheWorld and (TheWorld:HasTag("island") or TheWorld:HasTag("volcano"))then
		player.components.ngl_pathfollower:SetPathfinder("ngl_pathfinder")
		player.components.ngl_pathfollower:SetMoveModeOverride(1) -- DIRECTWALK MOVEMODE more fitting for sea sailing
	end

end)

----------------TRIGGER AND HALT----------------------
-- including the tweak of mapscreen, minimapwidget, smallmap, playercontroller

-- TRIGGER

modimport("scripts/postInits/mapscreenPostInit.lua")

AddSimPostInit(function ()
	local is_minimap_enable = false
	local is_smallmap_enable = false
	--On Error Resume Next
	pcall(function() is_minimap_enable = (require("widgets/minimapwidget") ~= nil) end)
	pcall(function() is_smallmap_enable = (require("widgets/smallmap") ~= nil) end)

	if is_minimap_enable and GetModConfigData("TWEAK_MINIMAP_ENABLE") then 
		modimport("scripts/postInits/minimapwidgetPostInit.lua")
	end

	if is_smallmap_enable and GetModConfigData("TWEAK_SMALLMAP_ENABLE") then 
		modimport("scripts/postInits/smallmapPostInit.lua")
	end
end)

-- HALT
modimport("scripts/postInits/playercontrollerPostInit.lua")


-------------------------MISC-----------------------
--it may cause many problems
--i just want to see how is it if all the creatures can detour
--and now you can get it in mod "Don't Blocked Together"
if not TheNet:GetIsServer() and GetModConfigData("TWEAK_DETOUR_ENABLE") then
	modimport("scripts/misc/tweak_avoid_obstacles.lua")
end

